#include "spectral.h"
#include "mel_basis.h"

void frame(const float32_t* x, const int32_t x_length, const int32_t frame_length, const int32_t hop_length, const float32_t* window, float32_t* frame_out)
{
    for (uint32_t step = 0; ; step++)
    {
        uint32_t x_pos = step * hop_length;
        if (x_pos + frame_length <= x_length)
        {
            for (uint32_t f_rel_pos = 0; f_rel_pos < frame_length; f_rel_pos++)
            {
				int32_t cnum = step*frame_length + f_rel_pos;
                frame_out[2*cnum] = x[x_pos+f_rel_pos] * window[f_rel_pos];
				frame_out[2*cnum+1] = 0.0;
            }
        }
        else
        {
            break;
        }
    } 
}

void pad(const float32_t* x, const int32_t x_length, const int32_t padl, const int32_t padr, float32_t *pad_out)
{
    for (uint32_t i = 0; i < padl; i++)
    {
        pad_out[i] = 0.0;
    }
    for (uint32_t i = 0; i < x_length; i++)
    {
        pad_out[padl+i] = x[i];
    }
    for (uint32_t i = 0; i < padr; i++)
    {
        pad_out[padl+x_length+i] = 0.0; 
    }
}

void stft(const float32_t* y, const int32_t y_length, const int32_t n_fft, const int32_t hop_length, const uint8_t center, float32_t* stft_out, const int32_t offset) 
{
//    const int32_t win_length = n_fft;
    float32_t fft_window[n_fft];
    arm_hanning_f32(fft_window, n_fft);
	
	arm_cfft_instance_f32 varInstCfftF32;
	
//	for(uint32_t i = 0; i < n_fft; i++)
//	{
//		printf("fft_window[%d]:%d\r\n",i,(int32_t)(fft_window[i]*10000));
//	}
    int32_t start = 0, extra = 0;

    // Pad the time series so that frames are centered
    if (center)
    {
        if (n_fft > y_length)
		{
            printf("MEL_INFO: n_fft=%d is too large for input signal of length=%d", n_fft, y_length);
        }
		
        // How many frames depend on left padding?
        int32_t start_k = ceil((int32_t)(n_fft / 2) / hop_length);

        // What's the first frame that depends on extra right-padding?
        int32_t tail_k = (y_length + (int32_t)(n_fft / 2) - n_fft) / hop_length + 1;

        if (tail_k <= start_k)
        {
            // If tail and head overlap, then just copy-pad the signal and carry on
            start = 0;
            extra = 0;
			
			int32_t y_padded_length = y_length + (int32_t)(n_fft / 2) + (int32_t)(n_fft / 2);
//            float32_t y_padded[y_padded_length];
			float32_t* y_padded = stft_out + offset;
            pad(y, y_length, (int32_t)(n_fft / 2), (int32_t)(n_fft / 2), y_padded);
            // padding[-1] = (n_fft // 2, n_fft // 2)
            // y = np.pad(y, padding, mode=pad_mode)
			
			int32_t y_mid_fnum = floor((y_padded_length - n_fft) / hop_length) + 1;
//			float32_t y_frames_mid[y_mid_fnum * n_fft * 2];
			float32_t* y_frames_mid = y_padded + y_padded_length;
			frame(y_padded, y_padded_length, n_fft, hop_length, fft_window, y_frames_mid);
//			printf("y_mid_fnum:%d\r\n",y_mid_fnum);
//			printf("start:%d\r\n",start);
//			for(uint32_t i = 0; i < y_mid_fnum; i++)
//			{
//				for(uint32_t j = 0; j < n_fft; j++)
//				{
//					printf("y_frames_mid[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_mid[2*(i*n_fft + j)]*10000),(int32_t)y_frames_mid[2*(i*n_fft + j)+1]);
//				}
//			}
			
			if (arm_cfft_init_f32(&varInstCfftF32, n_fft) != ARM_MATH_SUCCESS)
			{
				return;
			}

			for(uint32_t i = 0; i < y_mid_fnum; i++)
			{
				/* Process the data through the CFFT/CIFFT module */
				arm_cfft_f32(&varInstCfftF32, y_frames_mid+2*i*n_fft, 0, 1);

				/* Process the data through the Complex Magnitude Module for
				calculating the magnitude at each bin */
				arm_cmplx_mag_f32(y_frames_mid+2*i*n_fft, stft_out+i*(int32_t)(n_fft / 2 + 1), n_fft);
			}

        }
        else
        {
            // If tail and head do not overlap, then we can implement padding on each part separately
            // and avoid a full copy-pad

            // "Middle" of the signal starts here, and does not depend on head padding
            start = start_k * hop_length - (int32_t)(n_fft / 2);

            // +1 here is to ensure enough samples to fill the window
            int32_t y_pre_length = (start_k - 1) * hop_length - (int32_t)(n_fft / 2) + n_fft + 1 + (int32_t)(n_fft / 2);
//            float32_t y_pre[y_pre_length];
			float32_t* y_pre = stft_out + offset;
            pad(y, (start_k - 1) * hop_length - (int32_t)(n_fft / 2) + n_fft + 1, (int32_t)(n_fft / 2), 0, y_pre);

//            float32_t y_frames_pre[start_k * n_fft * 2];
			float32_t* y_frames_pre = y_pre + y_pre_length;
            frame(y_pre, y_pre_length, n_fft, hop_length, fft_window, y_frames_pre);

            // How many extra frames do we have from the head?
            extra = start_k;
			
//			printf("start_k:%d\r\n",start_k);
//			for(uint32_t i = 0; i < y_pre_length; i++)
//			{
//				printf("y_pre[%d]:%d\r\n",i,(int32_t)y_pre[i]);
//			}
//			for(uint32_t i = 0; i < start_k; i++)
//			{
//				for(uint32_t j = 0; j < n_fft; j++)
//				{
//					printf("y_frames_pre[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_pre[2*(i*n_fft + j)]*10000),(int32_t)y_frames_pre[2*(i*n_fft + j)+1]);
//				}
//			}

            // Determine if we have any frames that will fit inside the tail pad
            if (tail_k * hop_length - (int32_t)(n_fft / 2) + n_fft <= y_length + (int32_t)(n_fft / 2))
            {                
                int32_t y_post_start = (tail_k) * hop_length - (int32_t)(n_fft / 2);
                int32_t y_post_length = y_length - y_post_start + (int32_t)(n_fft / 2);
//                float32_t y_post[y_post_length];
				float32_t* y_post = y_frames_pre + start_k * n_fft * 2;
                pad(y+y_post_start, y_length-y_post_start, 0, (int32_t)(n_fft / 2), y_post);

                int32_t y_post_fnum = floor((y_post_length - n_fft) / hop_length) + 1;
//                float32_t y_frames_post[y_post_fnum * n_fft * 2];
				float32_t* y_frames_post = y_post + y_post_length;
                frame(y_post, y_post_length, n_fft, hop_length, fft_window, y_frames_post);

                // How many extra frames do we have from the tail?
                extra += y_post_fnum;
				
//				printf("y_post_start:%d\r\n",y_post_start);
//				printf("y_post_fnum:%d\r\n",y_post_fnum);
//				printf("y_post_length:%d\r\n",y_post_length);
//				for(uint32_t i = 0; i < y_post_length; i++)
//				{
//					printf("y_post[%d]:%d\r\n",i,(int32_t)y_post[i]);
//				}
//				for(uint32_t i = 0; i < y_post_fnum; i++)
//				{
//					for(uint32_t j = 0; j < n_fft; j++)
//					{
//						printf("y_frames_post[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_post[2*(i*n_fft + j)]*10000),(int32_t)y_frames_post[2*(i*n_fft + j)+1]);
//					}
//				}
				
				int32_t y_mid_fnum = floor((y_length - start - n_fft) / hop_length) + 1;
//                float32_t y_frames_mid[y_mid_fnum * n_fft * 2];
				float32_t* y_frames_mid = y_frames_post + y_post_fnum * n_fft * 2;
                frame(y+start, y_length-start, n_fft, hop_length, fft_window, y_frames_mid);
//				printf("y_mid_fnum:%d\r\n",y_mid_fnum);
//				printf("start:%d\r\n",start);
//				for(uint32_t i = 0; i < y_mid_fnum; i++)
//				{
//					for(uint32_t j = 0; j < n_fft; j++)
//					{
//						printf("y_frames_mid[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_mid[2*(i*n_fft + j)]*10000),(int32_t)y_frames_mid[2*(i*n_fft + j)+1]);
//					}
//				}
				
				if (arm_cfft_init_f32(&varInstCfftF32, n_fft) != ARM_MATH_SUCCESS)
				{
					return;
				}

				for(uint32_t i = 0; i < start_k; i++)
				{
					/* Process the data through the CFFT/CIFFT module */
					arm_cfft_f32(&varInstCfftF32, y_frames_pre+2*i*n_fft, 0, 1);

					/* Process the data through the Complex Magnitude Module for
					calculating the magnitude at each bin */
					arm_cmplx_mag_f32(y_frames_pre+2*i*n_fft, stft_out+i*(int32_t)(n_fft / 2 + 1), n_fft);
				}
				for(uint32_t i = 0; i < y_mid_fnum; i++)
				{
					/* Process the data through the CFFT/CIFFT module */
					arm_cfft_f32(&varInstCfftF32, y_frames_mid+2*i*n_fft, 0, 1);

					/* Process the data through the Complex Magnitude Module for
					calculating the magnitude at each bin */
					arm_cmplx_mag_f32(y_frames_mid+2*i*n_fft, stft_out+(start_k+i)*(int32_t)(n_fft / 2 + 1), n_fft);
				}
				for(uint32_t i = 0; i < y_post_fnum; i++)
				{
					/* Process the data through the CFFT/CIFFT module */
					arm_cfft_f32(&varInstCfftF32, y_frames_post+2*i*n_fft, 0, 1);
					

//					for(uint32_t j = 0; j < n_fft; j++)
//					{
//						printf("y_frames_post[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_post[2*(i*n_fft + j)]*10000),(int32_t)y_frames_post[2*(i*n_fft + j)+1]);
//					}

					/* Process the data through the Complex Magnitude Module for
					calculating the magnitude at each bin */
					arm_cmplx_mag_f32(y_frames_post+2*i*n_fft, stft_out+(start_k+y_mid_fnum+i)*(int32_t)(n_fft / 2 + 1), n_fft);
				}
				
            }
            else
            {    
                // In this event, the first frame that touches tail padding would run off
                // the end of the padded array
                // We'll circumvent this by allocating an empty frame buffer for the tail
                // this keeps the subsequent logic simple
                // post_shape = list(y_frames_pre.shape)
                // post_shape[-1] = 0
                // y_frames_post = np.empty_like(y_frames_pre, shape=post_shape)
//				float32_t y_frames_post[0];
				
				int32_t y_mid_fnum = floor((y_length - start - n_fft) / hop_length) + 1;
//                float32_t y_frames_mid[y_mid_fnum * n_fft * 2];
				float32_t* y_frames_mid = y_frames_pre + start_k * n_fft * 2;
                frame(y+start, y_length-start, n_fft, hop_length, fft_window, y_frames_mid);
//				printf("y_mid_fnum:%d\r\n",y_mid_fnum);
//				printf("start:%d\r\n",start);
//				for(uint32_t i = 0; i < y_mid_fnum; i++)
//				{
//					for(uint32_t j = 0; j < n_fft; j++)
//					{
//						printf("y_frames_mid[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_mid[2*(i*n_fft + j)]*10000),(int32_t)y_frames_mid[2*(i*n_fft + j)+1]);
//					}
//				}
				
				if (arm_cfft_init_f32(&varInstCfftF32, n_fft) != ARM_MATH_SUCCESS)
				{
					return;
				}

				for(uint32_t i = 0; i < start_k; i++)
				{
					/* Process the data through the CFFT/CIFFT module */
					arm_cfft_f32(&varInstCfftF32, y_frames_pre+2*i*n_fft, 0, 1);

					/* Process the data through the Complex Magnitude Module for
					calculating the magnitude at each bin */
					arm_cmplx_mag_f32(y_frames_pre+2*i*n_fft, stft_out+i*(int32_t)(n_fft / 2 + 1), n_fft);
				}
				for(uint32_t i = 0; i < y_mid_fnum; i++)
				{
					/* Process the data through the CFFT/CIFFT module */
					arm_cfft_f32(&varInstCfftF32, y_frames_mid+2*i*n_fft, 0, 1);

					/* Process the data through the Complex Magnitude Module for
					calculating the magnitude at each bin */
					arm_cmplx_mag_f32(y_frames_mid+2*i*n_fft, stft_out+(start_k+i)*(int32_t)(n_fft / 2 + 1), n_fft);
				}
//				for(uint32_t i = 0; i < y_post_fnum; i++)
//				{
//					/* Process the data through the CFFT/CIFFT module */
//					arm_cfft_f32(&varInstCfftF32, y_frames_post+2*i*n_fft, 0, 1);

//					/* Process the data through the Complex Magnitude Module for
//					calculating the magnitude at each bin */
//					arm_cmplx_mag_f32(y_frames_post+2*i*n_fft, stft_out+(start_k+y_mid_fnum+i)*(int32_t)(n_fft / 2 + 1), n_fft);
//				}
            }
        }
    }
    else
    {
        if (n_fft > y_length)
        {
            printf("MEL_INFO: n_fft=%d is too large for input signal of length=%d", n_fft, y_length);
			return;
        }
        // "Middle" of the signal starts at sample 0
        start = 0;
        // We have no extra frames
        extra = 0;
		
		int32_t y_mid_fnum = floor((y_length - n_fft) / hop_length) + 1;
//		float32_t y_frames_mid[y_mid_fnum * n_fft * 2];
		float32_t* y_frames_mid = stft_out + offset;
		frame(y, y_length, n_fft, hop_length, fft_window, y_frames_mid);
//		printf("y_mid_fnum:%d\r\n",y_mid_fnum);
//		printf("start:%d\r\n",start);
//		for(uint32_t i = 0; i < y_mid_fnum; i++)
//		{
//			for(uint32_t j = 0; j < n_fft; j++)
//			{
//				printf("y_frames_mid[%d][%d]:%d+i%d\r\n",i,j,(int32_t)(y_frames_mid[2*(i*n_fft + j)]*10000),(int32_t)y_frames_mid[2*(i*n_fft + j)+1]);
//			}
//		}
//		
		if (arm_cfft_init_f32(&varInstCfftF32, n_fft) != ARM_MATH_SUCCESS)
		{
			return;
		}
		for(uint32_t i = 0; i < y_mid_fnum; i++)
		{
			/* Process the data through the CFFT/CIFFT module */
			arm_cfft_f32(&varInstCfftF32, y_frames_mid+2*i*n_fft, 0, 1);

			/* Process the data through the Complex Magnitude Module for
			calculating the magnitude at each bin */
			arm_cmplx_mag_f32(y_frames_mid+2*i*n_fft, stft_out+i*(int32_t)(n_fft / 2 + 1), n_fft);
		}
    }
} 

arm_matrix_instance_f32 S, M, SMM;

void mel_basis_init()
{
	arm_mat_init_f32(&M, 513, 64, mel_basis);
}

float32_t* melspectrogram(const float32_t* y, const int32_t y_length, const int32_t sr, const int32_t n_fft, const int32_t hop_length, const uint8_t center, const int32_t n_mels, float32_t* sdram)
{
	// ��ʱ����Ҷ�任
    int32_t start = 0, extra = 0, stft_out_fnum = 0, stft_out_length, stft_height = (int32_t)(n_fft / 2 + 1);

    // Pad the time series so that frames are centered
    if (center)
    {
        // How many frames depend on left padding?
        int32_t start_k = ceil((int32_t)(n_fft / 2) / hop_length);

        // What's the first frame that depends on extra right-padding?
        int32_t tail_k = (y_length + (int32_t)(n_fft / 2) - n_fft) / hop_length + 1;

        if (tail_k <= start_k)
        {
            // If tail and head overlap, then just copy-pad the signal and carry on
            start = 0;
            extra = 0;
			
			int32_t y_padded_length = y_length + (int32_t)(n_fft / 2) + (int32_t)(n_fft / 2);
			int32_t y_mid_fnum = floor((y_padded_length - n_fft) / hop_length) + 1;
			
			stft_out_fnum = y_mid_fnum;
			stft_out_length = (stft_out_fnum - 1) * stft_height + n_fft;

        }
        else
        {
            // If tail and head do not overlap, then we can implement padding on each part separately
            // and avoid a full copy-pad

            // "Middle" of the signal starts here, and does not depend on head padding
            start = start_k * hop_length - (int32_t)(n_fft / 2);

            // +1 here is to ensure enough samples to fill the window
            int32_t y_pre_length = (start_k - 1) * hop_length - (int32_t)(n_fft / 2) + n_fft + 1 + (int32_t)(n_fft / 2);

            // How many extra frames do we have from the head?
            extra = start_k;

            // Determine if we have any frames that will fit inside the tail pad
            if (tail_k * hop_length - (int32_t)(n_fft / 2) + n_fft <= y_length + (int32_t)(n_fft / 2))
            {                
                int32_t y_post_start = (tail_k) * hop_length - (int32_t)(n_fft / 2);
                int32_t y_post_length = y_length - y_post_start + (int32_t)(n_fft / 2);

                int32_t y_post_fnum = floor((y_post_length - n_fft) / hop_length) + 1;

                // How many extra frames do we have from the tail?
                extra += y_post_fnum;
				
				int32_t y_mid_fnum = floor((y_length - start - n_fft) / hop_length) + 1;
				
				stft_out_fnum = extra + y_mid_fnum;
				stft_out_length = (stft_out_fnum - 1) * stft_height + n_fft;
            }
            else
            {    
                // In this event, the first frame that touches tail padding would run off
                // the end of the padded array
                // We'll circumvent this by allocating an empty frame buffer for the tail
                // this keeps the subsequent logic simple
                // post_shape = list(y_frames_pre.shape)
                // post_shape[-1] = 0
                // y_frames_post = np.empty_like(y_frames_pre, shape=post_shape)
//				float32_t y_frames_post[0];
				
				int32_t y_mid_fnum = floor((y_length - start - n_fft) / hop_length) + 1;

				stft_out_fnum = extra + y_mid_fnum;
				stft_out_length = (stft_out_fnum - 1) * stft_height + n_fft;
				
            }
        }
    }
    else
    {
        if (n_fft > y_length)
        {
            printf("MEL_INFO: n_fft=%d is too large for input signal of length=%d", n_fft, y_length);
			return 0;
        }
        // "Middle" of the signal starts at sample 0
        start = 0;
        // We have no extra frames
        extra = 0;
		
		int32_t y_mid_fnum = floor((y_length - n_fft) / hop_length) + 1;
		
		stft_out_fnum = y_mid_fnum;
		stft_out_length = (stft_out_fnum - 1) * stft_height + n_fft;
	
    }
//	float32_t stft_out[stft_out_length];
	float32_t* stft_out = sdram;
	stft(y, y_length, n_fft,hop_length, center, stft_out, stft_out_length);
	
//	printf("MEL_INFO: stft_out_fnum:%d\r\n",stft_out_fnum);
//	printf("MEL_INFO: stft_height:%d\r\n",stft_height);
//	for(uint32_t i = 0; i < stft_out_fnum; i++)
//	{
//		for(uint32_t j = 0; j < stft_height; j++)
//		{
//			printf("stft_out[%d][%d]:%d\r\n",i,j,(int32_t)(stft_out[i*stft_height + j]*10000));
//		}
//	} 
	
	float32_t* mel_out = stft_out + stft_out_fnum * stft_height;
	
	arm_mat_init_f32(&S, stft_out_fnum, stft_height, stft_out);
	
	arm_mat_init_f32(&SMM, stft_out_fnum, 64, mel_out);
	
//	for(uint32_t i = 0; i < 64; i++)
//	{
//		for(uint32_t j = 0; j < 513; j++)
//		{
//			printf("mel_basis[%d][%d]:%d\r\n",i,j,(int32_t)(mel_basis[i + j*64]*10000));
//		}
//	} 
	
	
	/* calculation of S Multiply with M */
	if (arm_mat_mult_f32(&S, &M, &SMM) != ARM_MATH_SUCCESS)
	{
		return 0;
	}
	
//	for(uint32_t i = 0; i < stft_out_fnum; i++)
//	{
//		for(uint32_t j = 0; j < 64; j++)
//		{
//			printf("mel_out[%d][%d]:%d\r\n",i,j,(int32_t)(mel_out[i*64 + j]*10000));
//		}
//	} 
	return mel_out;

}







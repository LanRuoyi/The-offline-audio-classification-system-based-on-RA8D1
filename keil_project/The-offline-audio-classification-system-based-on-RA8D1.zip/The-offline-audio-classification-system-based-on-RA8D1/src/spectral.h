#ifndef SPECTRAL_H
#define SPECTRAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "arm_math.h"
#include <stdio.h> 
#include <stdlib.h> 


void mel_basis_init();
void stft(const float32_t* y, const int32_t y_length, const int32_t n_fft, const int32_t hop_length, const uint8_t center, float32_t* stft_out, const int32_t offset);
float32_t* melspectrogram(const float32_t* y, const int32_t y_length, const int32_t sr, const int32_t n_fft, const int32_t hop_length, const uint8_t center, const int32_t n_mels, float32_t* sdram);
	
#ifdef __cplusplus
}
#endif

#endif

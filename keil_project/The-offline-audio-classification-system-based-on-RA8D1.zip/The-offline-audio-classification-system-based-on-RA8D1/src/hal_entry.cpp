/*********************************************************************************************************************
* RA8D1 Opensourec Library ����RA8D1 ��Դ�⣩��һ�����ڹٷ� SDK �ӿڵĵ�������Դ��
* Copyright (c) 2025 SEEKFREE ��ɿƼ�
* 
* ���ļ��� RA8D1 ��Դ���һ����
* 
* RA8D1 ��Դ�� ���������
* �����Ը���������������ᷢ���� GPL��GNU General Public License���� GNUͨ�ù�������֤��������
* �� GPL �ĵ�3�棨�� GPL3.0������ѡ��ģ��κκ����İ汾�����·�����/���޸���
* 
* ����Դ��ķ�����ϣ�����ܷ������ã�����δ�������κεı�֤
* ����û�������������Ի��ʺ��ض���;�ı�֤
* ����ϸ����μ� GPL
* 
* ��Ӧ�����յ�����Դ���ͬʱ�յ�һ�� GPL �ĸ���
* ���û�У������<https://www.gnu.org/licenses/>
* 
* ����ע����
* ����Դ��ʹ�� GPL3.0 ��Դ����֤Э�� ������������Ϊ���İ汾
* ��������Ӣ�İ��� libraries/doc �ļ����µ� GPL3_permission_statement.txt �ļ���
* ����֤������ libraries �ļ����� �����ļ����µ� LICENSE �ļ�
* ��ӭ��λʹ�ò����������� ���޸�����ʱ���뱣����ɿƼ��İ�Ȩ����������������
* 
* �ļ�����          hal_entry
* ��˾����          �ɶ���ɿƼ����޹�˾
* �汾��Ϣ          �鿴 libraries/doc �ļ����� version �ļ� �汾˵��
* ��������          MDK 5.38
* ����ƽ̨          RA8D1
* ��������          https://seekfree.taobao.com/
* 
* �޸ļ�¼
* ����              ����                ��ע
* 2025-03-25        ZSY            first version
********************************************************************************************************************/
#include "zf_common_headfile.h"

#include "tensorflow/lite/core/c/common.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_profiler.h"
#include "tensorflow/lite/micro/recording_micro_interpreter.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/micro/tflite_bridge/micro_error_reporter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/micro/cortex_m_generic/debug_log_callback.h"
#include "tensorflow/lite/micro/micro_time.h"

#include "audio.h"
#include "spectral.h"


//Exact size is 88 kB but added 2 kB for margin.
constexpr int tensor_arena_2_class_size = 0.25 * 1024 * 1024;
static uint8_t tensor_arena_2_class[tensor_arena_2_class_size] BSP_PLACE_IN_SECTION(".sdram");

constexpr int tensor_arena_6_class_size = 1 * 1024 * 1024;
static uint8_t tensor_arena_6_class[tensor_arena_6_class_size] BSP_PLACE_IN_SECTION(".sdram");

float32_t mel_sdram_area[1024*1024*1] BSP_PLACE_IN_SECTION(".sdram");

#define WAV_LEN 32400
float32_t mic_get_data[WAV_LEN] BSP_PLACE_IN_SECTION(".sdram");
uint32 mic_get_data_num = 0;
							   
void hal_entry(void)
{
	uint32_t start_ticks = tflite::GetCurrentTimeTicks();
	uint8_t mode = 0, cry_times = 0;
	
    init_sdram();               // ��ʼ���������ź�SDRAM  ȫ�ֱ���������BSP_PLACE_IN_SECTION(".sdram")��������ת��SDRAM��                         
    debug_init();               // ��ʼ��Debug����
    system_delay_ms(300);       // �ȴ��������������ϵ����
	sd_init();                  // ��ʼ��SD������
	adc_init();                 // ��ʼ����˷�ADC
	dac_init();                 // ��ʼ��������DAC
	mel_basis_init();
	
	gpio_set_level(LED1, 1);   
    gpio_set_level(LED2, 1);  
    gpio_set_level(LED3, 0);  
    gpio_set_level(LED4, 1);
	
	uint32_t pos;
	float32_t max, min, gap, normalization_factor;
	RegisterDebugLogCallback(debug_write_buffer_tf);

	MicroPrintf("Welcome to use CNN demo.\r\n");
	
	sd_read_model();
	
	// ����ģ��
	const tflite::Model* model_2_class = tflite::GetModel(model_2_class_array);
	const tflite::Model* model_6_class = tflite::GetModel(model_6_class_array);
	if (model_2_class->version() != TFLITE_SCHEMA_VERSION) 
	{
		MicroPrintf(
			"Model_2_calss provided is schema version %d not equal "
			"to supported version %d.",
			model_2_class->version(), TFLITE_SCHEMA_VERSION);
		return;
	}
	else if (model_6_class->version() != TFLITE_SCHEMA_VERSION)
	{
		MicroPrintf(
			"Model_6_calss provided is schema version %d not equal "
			"to supported version %d.",
			model_6_class->version(), TFLITE_SCHEMA_VERSION);
		return;
	}
	
	MicroPrintf("model_2_class ver:%d model_6_class ver:%d\r\n", model_2_class->version(), model_6_class->version());

	// ���ò���������
	tflite::MicroMutableOpResolver<6> micro_op_resolver_2_class;
	// ���� CNN �������� Conv2D
	micro_op_resolver_2_class.AddConv2D();
	micro_op_resolver_2_class.AddRelu();
	micro_op_resolver_2_class.AddMaxPool2D();
	micro_op_resolver_2_class.AddMean();
	micro_op_resolver_2_class.AddFullyConnected();
	micro_op_resolver_2_class.AddDepthwiseConv2D();
	
	tflite::MicroMutableOpResolver<5> micro_op_resolver_6_class;
	// ���� CNN �������� Conv2D
	micro_op_resolver_6_class.AddConv2D();
	micro_op_resolver_6_class.AddRelu();
	micro_op_resolver_6_class.AddMaxPool2D();
	micro_op_resolver_6_class.AddMean();
	micro_op_resolver_6_class.AddFullyConnected();
	
	// ��ʼ��������
	tflite::MicroInterpreter interpreter_2_class(model_2_class, micro_op_resolver_2_class, tensor_arena_2_class, tensor_arena_2_class_size);
	tflite::MicroInterpreter interpreter_6_class(model_6_class, micro_op_resolver_6_class, tensor_arena_6_class, tensor_arena_6_class_size);
	
	
	// ��������
	TfLiteStatus allocate_status = interpreter_2_class.AllocateTensors();
	if (allocate_status != kTfLiteOk) 
	{
		MicroPrintf("2 AllocateTensors() failed");
		return;
	}
	allocate_status = interpreter_6_class.AllocateTensors();
	if (allocate_status != kTfLiteOk) 
	{
		MicroPrintf("6 AllocateTensors() failed");
		return;
	}
	printf("AllocateTensors() succeed\r\n");
	
	// ��ȡ������������
	TfLiteTensor* input_tensor_2_class = interpreter_2_class.input(0);
	TfLiteTensor* input_tensor_6_class = interpreter_6_class.input(0);
	
	TfLiteTensor* output_tensor_2_class = interpreter_2_class.output(0);
	TfLiteTensor* output_tensor_6_class = interpreter_6_class.output(0);
	
	uint32_t end_ticks = tflite::GetCurrentTimeTicks();
	// �����ʱ�����룩
	uint32_t duration_ms = tflite::TicksToMs(end_ticks - start_ticks);
	MicroPrintf("Init duration_ms %d ms\r\n", duration_ms);
	
	while(1)
	{
		gpio_set_level(LED1, 0); 
		mic_get_data_num = 0;
		while(mic_get_data_num < WAV_LEN)
		{
			mic_get_data[mic_get_data_num++] = adc_get_mic() - 2048.0;
			system_delay_us(121);
		}
		gpio_set_level(LED1, 1); 
		
		if (gpio_get_level(KEY1) == 0)
		{
			system_delay_ms(10);
			if (gpio_get_level(KEY1) == 0)
			{
				mode = 0;
				cry_times = 0;
				gpio_set_level(LED3, 0);  
				gpio_set_level(LED4, 1);
			}
		}
		else if(gpio_get_level(KEY2) == 0)
		{
			system_delay_ms(10);
			if (gpio_get_level(KEY2) == 0)
			{
				mode = 1;
				cry_times = 0;
				gpio_set_level(LED3, 1);  
				gpio_set_level(LED4, 0);
			}
		}
		
		if (mode == 0)
		{
			arm_absmax_f32(mic_get_data, WAV_LEN, &max, &pos);
			normalization_factor = 1 / max;
			
			for(uint32_t i = 0;i < WAV_LEN; ++i)
			{
				mic_get_data[i] = mic_get_data[i] * normalization_factor;
			}
			
			float32_t* mel_out = melspectrogram(mic_get_data, WAV_LEN, 8100, 1024, 512, 1, 64, mel_sdram_area);
			
			
			arm_max_f32(mel_out, 64*64, &max, &pos);
			arm_min_f32(mel_out, 64*64, &min, &pos);
			gap = max - min;
			
			if (input_tensor_2_class->type == kTfLiteInt8) 
			{
				float scale = input_tensor_2_class->params.scale;
				int zero_point = input_tensor_2_class->params.zero_point;
				for (uint8_t y = 0; y < 64; ++y) 
				{
					for (uint8_t x = 0; x < 64; ++x) 
					{
						input_tensor_2_class->data.int8[y * 64 + x] = static_cast<int8_t>(((mel_out[y * 64 + x] - min ) / gap) / scale + zero_point);
					}
				}
			}
		
			gpio_set_level(LED2, 0); 
			
			start_ticks = tflite::GetCurrentTimeTicks();
			// ִ������
			TfLiteStatus invoke_status = interpreter_2_class.Invoke();
			if (invoke_status != kTfLiteOk) 
			{
				MicroPrintf("Invoke() failed");
				return;
			}
			
			end_ticks = tflite::GetCurrentTimeTicks();
			// �����ʱ�����룩
			duration_ms = tflite::TicksToMs(end_ticks - start_ticks);
			
			gpio_set_level(LED2, 1); 
			
			if (output_tensor_2_class->type == kTfLiteInt8) 
			{
				
				float scale = output_tensor_2_class->params.scale;
				int zero_point = output_tensor_2_class->params.zero_point;
				int8_t* output_data = output_tensor_2_class->data.int8;
				int num_classes = output_tensor_2_class->bytes / sizeof(int8_t);
				
				int max_index = 0;
				int8_t max_value = output_data[0];


				for (int i = 0; i < num_classes; ++i) 
				{
					int8_t value = output_data[i];
					
					if (value > max_value) 
					{
						max_value = value;
						max_index = i;
					}
				}
				
				switch (max_index)
				{
					case 0:
						MicroPrintf("CRY Infer duration_ms %d ms\r\n", duration_ms);
						if (++cry_times > 1)
						{
							cry_times = 0;
							mic_get_data_num = 0;
							while(mic_get_data_num < baby_cry_length)
							{
								dac_out(uint16_t(baby_cry[mic_get_data_num++] + 2048.0));
								system_delay_us(123);
							}
						}
						break;
					case 1:
						MicroPrintf("NON CRY Infer duration_ms %d ms\r\n", duration_ms);
						cry_times = 0;
						break;
					default:
						break;
				}
			}
		}
		else if (mode == 1)
		{
			arm_absmax_f32(mic_get_data, WAV_LEN, &max, &pos);
			normalization_factor = 1 / max;
	//		printf("absmax:%d\r\n", (int16_t)max);
			
			for(uint32_t i = 0;i < WAV_LEN; ++i)
			{
				mic_get_data[i] = mic_get_data[i] * normalization_factor;
			}
			
			float32_t* mel_out = melspectrogram(mic_get_data, WAV_LEN, 8100, 1024, 512, 1, 64, mel_sdram_area);
			
			
			arm_max_f32(mel_out, 64*64, &max, &pos);
			arm_min_f32(mel_out, 64*64, &min, &pos);
			gap = max - min;
			
			if (input_tensor_2_class->type == kTfLiteInt8) 
			{
				float scale = input_tensor_2_class->params.scale;
				int zero_point = input_tensor_2_class->params.zero_point;
				for (uint8_t y = 0; y < 64; ++y) 
				{
					for (uint8_t x = 0; x < 64; ++x) 
					{
						input_tensor_2_class->data.int8[y * 64 + x] = static_cast<int8_t>(((mel_out[y * 64 + x] - min ) / gap) / scale + zero_point);
					}
				}
			}
		
			gpio_set_level(LED2, 0); 
			
			start_ticks = tflite::GetCurrentTimeTicks();
			// ִ������
			TfLiteStatus invoke_status = interpreter_2_class.Invoke();
			if (invoke_status != kTfLiteOk) 
			{
				MicroPrintf("Invoke() failed");
				return;
			}
			
			
			
			if (output_tensor_2_class->type == kTfLiteInt8) 
			{
				
				float scale = output_tensor_2_class->params.scale;
				int zero_point = output_tensor_2_class->params.zero_point;
				int8_t* output_data = output_tensor_2_class->data.int8;
				int num_classes = output_tensor_2_class->bytes / sizeof(int8_t);
				
				int max_index = 0;
				int8_t max_value = output_data[0];

				for (int i = 0; i < num_classes; ++i) 
				{
					int8_t value = output_data[i];
					if (value > max_value) 
					{
						max_value = value;
						max_index = i;
					}
				}
				
				switch (max_index)
				{
					case 0:
						if (++cry_times == 1)
						{
							end_ticks = tflite::GetCurrentTimeTicks();
							// �����ʱ�����룩
							duration_ms = tflite::TicksToMs(end_ticks - start_ticks);
							
							gpio_set_level(LED2, 1); 
							MicroPrintf("CRY Infer duration_ms %d ms\r\n", duration_ms);
						}
						else if (++cry_times > 1)
						{
							cry_times = 0;
							if (input_tensor_6_class->type == kTfLiteInt8) 
							{
								float scale = input_tensor_6_class->params.scale;
								int zero_point = input_tensor_6_class->params.zero_point;
								for (uint8_t y = 0; y < 64; ++y) 
								{
									for (uint8_t x = 0; x < 64; ++x) 
									{
										input_tensor_6_class->data.int8[y * 64 + x] = static_cast<int8_t>(((mel_out[y * 64 + x] - min ) / gap) / scale + zero_point);
									}
								}
							} 
							
							// ִ������
							TfLiteStatus invoke_status = interpreter_6_class.Invoke();
							if (invoke_status != kTfLiteOk) 
							{
								MicroPrintf("Invoke() failed");
								return;
							}
							
							end_ticks = tflite::GetCurrentTimeTicks();
							// �����ʱ�����룩
							duration_ms = tflite::TicksToMs(end_ticks - start_ticks);
							
							gpio_set_level(LED2, 1); 
							
							if (output_tensor_6_class->type == kTfLiteInt8) 
							{
								
								scale = output_tensor_6_class->params.scale;
								zero_point = output_tensor_6_class->params.zero_point;
								output_data = output_tensor_6_class->data.int8;
								num_classes = output_tensor_6_class->bytes / sizeof(int8_t);
								
								max_index = 0;
								max_value = output_data[0];

								for (int i = 0; i < num_classes; ++i) 
								{
									int8_t value = output_data[i];
									if (value > max_value) 
									{
										max_value = value;
										max_index = i;
									}
								}
								
								switch (max_index)
								{
									case 0:
										MicroPrintf("AWAKE Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_awake_length)
										{
											dac_out(uint16_t(baby_awake[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									case 1:
										MicroPrintf("DIAPER Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_diaper_length)
										{
											dac_out(uint16_t(baby_diaper[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									case 2:
										MicroPrintf("HUG Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_hug_length)
										{
											dac_out(uint16_t(baby_hug[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									case 3:
										MicroPrintf("HUNGRY Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_hungry_length)
										{
											dac_out(uint16_t(baby_hungry[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									case 4:
										MicroPrintf("SLEEPY Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_sleepy_length)
										{
											dac_out(uint16_t(baby_sleepy[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									case 5:
										MicroPrintf("UNCOMFORTABLE Infer duration_ms %d ms\r\n", duration_ms);
										mic_get_data_num = 0;
										while(mic_get_data_num < baby_uncomfortable_length)
										{
											dac_out(uint16_t(baby_uncomfortable[mic_get_data_num++] + 2048.0));
											system_delay_us(123);
										}
										break;
									default:
										break;
									
								}
							}
						}
						break;
					case 1:
						MicroPrintf("NON CRY Infer duration_ms %d ms\r\n", duration_ms);
						cry_times = 0;
						break;
					default:
						break;
				}
			}
		}
	}
	
}
// **************************** �������� ****************************

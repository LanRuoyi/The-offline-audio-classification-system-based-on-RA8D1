
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'zf_ra_motherboard_demo' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* tensorflow::Machine Learning:TensorFlow:Kernel:CMSIS-NN:1.25.2 */
// enabling global pre includes 
        #define TF_LITE_STATIC_MEMORY 1
        #define CMSIS_NN


#endif /* PRE_INCLUDE_GLOBAL_H */
